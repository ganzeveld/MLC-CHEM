This directory contains the Multi-Layer Canopy CHemical Exchange Model (MLC-CHEM) v2 (January 2013).
contact Laurens.ganzeveld@wur.nl for feedback on its application, issues, etc
