This directory contains the Multi-Layer Canopy CHemical Exchange Model (MLC-CHEM) v5 (June 2023).
contact Laurens.ganzeveld@wur.nl for feedback on its application, issues, etc
